# A guide to play firewatch, and a day by day transcription.
# I have paused this project until June 2021
