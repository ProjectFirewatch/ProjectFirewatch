# Firewatch Guide

# What is Firewatch?
### Firewatch is a single-player first-person mystery set in the Wyoming wilderness, where your only emotional lifeline is the person on the other end of a handheld radio.
# I have paused this project until June 2021

[![Hits](https://hits.seeyoufarm.com/api/count/incr/badge.svg?url=https%3A%2F%2Fgithub.com%2FSophiaAtkinson%2FFirewatch-Guide&count_bg=%23FF6B00&title_bg=%23000000&icon=mediafire.svg&icon_color=%23E7E7E7&title=Page+Views+&edge_flat=false)](https://hits.seeyoufarm.com)

![Firewatch Intro Image](https://firewatch.ml/cdn/Firewatch%20Intro%20Image.jpg)
<!-- blank line -->

[Firewatch Playthrough No Commentary](https://www.youtube.com/watch?v=NGDuoCAu0Rg&t=4552s) 2:04 Hours
<!-- blank line -->

# BELOW ARE MAJOR SPOILERS!

<!-- blank line -->
# The Prologue

You get options and you can pick whatever you want, But during the prologue, you start your 2-day hike up to your tower. When you get up to the tower you turn on your light, then you hear a walkie-talkie going off, saying "Hello two forks tower!". You say Hello to Delilah, who is your boss, you will be spending the rest of your time as a Firewatch with her.
<!-- blank line -->
![Firewatch Intro Image](https://firewatch.ml/cdn/arch.jpg)
<!-- blank line -->
# Day One
 Day 1 starts off with you (Henry) sitting at your desk getting some writing on your typewriter. Delilah chimes in on your walkie-talkie to say "good morning, or should I say good afternoon." Since there are a few hours of daylight left she wants to try to get some work in, Since it is your first day she wants to get you acquainted with the job, She wants you to look at the round table in the middle of your tower. "This is the Osbourne Fire Finder. Invented in 1914 by W.B..." You respond Osbourne?, "You use this to spot you guessed it, fi-what the fuck" Your quick run-through has been interrupted, by fireworks out your west-facing window. Now you have to go stop whoever is shooting off the Fireworks but to get down to the lake where the fireworks are going off you need a rope to get down the shale. Luckily there are these neat little supply boxes spread around the forest, "The code is "1-2-3-4" it's actually that for all of them" Delilah says. You open the box, there is a map and some notes, a map, and the rope, you copy the map to your map, read the note, then take the rope, there is a granola bar but, you decide to leave it. You make your way down the hill and then a little outcropping, you get to the shale slid, it's fairly steep, Delilah says that it's not named on their topos, so you decide to give it a name, you can name it 1 of 3 things, Cripple Gultch, Widowmaker, or Shitty boss is going to get me killed hill. I normally chose Cripple Gultch, but this time I chose, Shitty boss is going to get me killed hill. while going down the hill your rope snaps sending you down the shale, You survive but the name is fitting now. Coming down the hill you find a lot of empty beer cans, you decide to clean them up, keep the forest looking nice. The idiots down at the lake also decided to make a campfire, you put the fire out, then you find, a bottle of whiskey, a bundle of fireworks, two backpacks, then clothes. You tell Delilah about taking the fireworks, and then about the clothes, she makes a comment about "Nudie pyromaniacs." You start walking through some bushes, you find a bra, and two pairs of panties... There are two naked laddies in the lake setting off fireworks, You get their attention, but since they are teens they say this "Hey, you fucking fatso! Leave us alone." You tell them to take it easy with the fireworks. "You oughta take it easy with the Sizzler buffet." Now you let your anger get the best of you, you grab their boombox, and you through it in the lake... "Light another firework and it won't be your stereo I wreck." you say, now you make your way out of the lake, but since your rope broke you need to make your way through thunder canyon. "Hey, did that go okay?" Delilah asks, you lie and said it went fine. While you make your way back Delilah says, "So... I have a bit of a confession to make." "What is it?" you ask. "Um... Look, I was drunk last night when I welcomed you to the job." She apologies for being putting you on the spot about why your out here. You accept her apology. After that you keep walking, then you hear thunder, there is a storm out to the north of you. You find a supply box, you open it, and do your thing, you also find a flashlight in there. Then you find a cave, you go into the cave, part of the cave is gated off, they lost the keys a little while ago, so its secrets are locked away for good. You are very close to the tower when you see a light, then a figure, you tell Delilah, she makes fun of you. You climb up to the land of the tower, you lean on a sign, and boom you fall so does the sign. You walk up to the tower, you see your typewriter out on the ground by the stairs, you walk up the stairs with your typewriter, you find some broken glass, someone broke into the tower. They threw everything to shit, and they took your sheets, that's all they took. Delilah lets the forest service know what happened. You think that the girls at the lake did this. "I need you to feel safe out here," says Delilah, You ask her to locate you to the Forest service weapons cache. She says "Yeah... Someone made the decision years ago that leaving someone with a gun and infinite amounts of alone time was kinda a bad idea." That's Day one check back for Day Two soon.
<!-- blank line -->
![Firewatch Intro Image](https://firewatch.ml/cdn/pork.jpg)
<!-- blank line -->
# I have paused this project until June 2021
<!-- blank line -->
Firewatch.ml is a community website and is not affiliated with Firewatch or Campo Santo.
